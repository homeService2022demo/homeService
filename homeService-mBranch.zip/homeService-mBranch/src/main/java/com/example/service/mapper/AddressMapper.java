package com.example.service.mapper;

import com.example.data.dto.AddressDto;
import com.example.data.entity.Address;
import org.springframework.stereotype.Service;

@Service
public class AddressMapper {
    public AddressDto convertToDto(Address address) {
        AddressDto addressDto;
        //TODO
        return null;
    }

    public Address convertToEntity(AddressDto addressDto) {
        Address address;
        //TODO
        return null;
    }
}
