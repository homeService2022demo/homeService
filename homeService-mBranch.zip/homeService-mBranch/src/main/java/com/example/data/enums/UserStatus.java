package com.example.data.enums;

public enum UserStatus {
    ACTIVE,
    DEACTIVATE
}
