package com.example.data.enums;

public enum OrderPaymentStatus {
    PAID,
    NOT_PAID
}
