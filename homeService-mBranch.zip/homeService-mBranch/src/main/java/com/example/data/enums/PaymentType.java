package com.example.data.enums;

public enum PaymentType {
    BY_CASH,
    BY_CARD,
    BY_WALLET,
}
