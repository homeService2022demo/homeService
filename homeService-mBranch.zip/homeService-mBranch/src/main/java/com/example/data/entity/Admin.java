package com.example.data.entity;

public class Admin {
    //TODO : default pass
}
