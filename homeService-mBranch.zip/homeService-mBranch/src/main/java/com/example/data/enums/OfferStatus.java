package com.example.data.enums;

public enum OfferStatus {
    NEW,
    WAITING,
    ACCEPTED,
    REJECTED,
    CANCELED
}
