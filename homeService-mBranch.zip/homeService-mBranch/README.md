# homeService
This is a Web Application for homeservices.
There is two main roles in this web application: Customer and Expert.
Customers can make an order for Services they need.
Then they must wait for Experts to send an offer for those orders.
after that customer can choose on offer.
then expert will go and do the work.
customer must pay for expert.
expert and customer can comment on and rate eachother.
